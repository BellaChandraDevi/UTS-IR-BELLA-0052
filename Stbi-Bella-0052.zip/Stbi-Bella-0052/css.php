<!DOCTYPE html>
<html>
<title>STBI-UNISBANK</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
<style>
body,h1,h2,h3,h4,h5 {font-family: "Poppins", sans-serif}
body {font-size:16px;}
.w3-half img{margin-bottom:-6px;margin-top:16px;opacity:0.8;cursor:pointer}
.w3-half img:hover{opacity:1}
</style>
<body>

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-red w3-collapse w3-top w3-large w3-padding" style="z-index:3;width:300px;font-weight:bold;" id="mySidebar"><br>
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-button w3-hide-large w3-display-topleft" style="width:100%;font-size:22px">Close Menu</a>
  <div class="w3-container">
    <h3 class="w3-padding-70"><b>Bella Chandra Devi<br>14.01.55.0052</b></h3>
  </div>
  <div class="top-nav s-12 l-10">
            <p class="nav-text"></p>
            <ul class="right chevron">
              <li><a href="?menu=home"onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Home</a></li>
              <li><a href="?menu=profil"onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Profile</a></li>
              <li><a href="?menu=profil"onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Menu</a>
                <ul>
                    	
						<li><a href="?menu=upload" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Upload</a></li>
						<li><a href="?menu=stem" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Kata Dasar</a></li>
						<li><a href="?menu=query" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Cari Query</a></li>
						<li><a href="?menu=hitungbobot" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Hitung Bobot</a></li>
						<li><a href="?menu=hitungvektor" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Hitung Vektor</a></li>
						<li><a href="?menu=awalquery" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Cari Query 2</a></li>
						<li><a href="?menu=download" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Download</a></li>
						
						 
						
                </ul>
			</ul> 
          </div>
</nav>



<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:340px;margin-right:40px">

  <!-- Header -->
  <div class="w3-container" style="margin-top:80px" id="showcase"><center>
    <h1 class="w3-jumbo"><b>INFORMATION RETRIEVAL</b></h1>
    <h1 class="w3-xxxlarge w3-text-red"><b>STBI (Sistem Temu Balik Informasi)</b></h1>
    <hr style="width:900px;border:5px solid red" class="w3-round">
  </div>
  <div class="margin" align='center'>
            <?php
				error_reporting(0);
				if($_GET[menu]=='')
					{
					include('home.php');
					}
				else
					{
					include($_GET[menu].'.php');
					}
			?>
        </div><p>
  

<!-- End page content -->
</div>

<section class="padding background-dark">
        <div class="line">
          <div class="s-12 l-6">
           <b><MARQUEE  direction="right" height="50" scrollamount="10" width="98%">TERIMA KASIH SUDAH BERKUNJUNG</MARQUEE>
          </div>
        </div>
      </section>

<!-- W3.CSS Container -->
<div class="w3-light-grey w3-container w3-padding-32" style="margin-top:75px;padding-right:58px"><p class="w3-right">Created by <a href="https://www.w3schools.com/w3css/default.asp" title="W3.CSS" target="_blank" class="w3-hover-opacity">Bella C.D</a></p></div>



</body>
</html>
