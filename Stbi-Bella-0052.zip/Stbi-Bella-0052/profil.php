
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

	<div class="w3-row-padding">
 
      	<div class="w3-column-padding" align="left">
        <ul class=" w3-ul w3-light-grey w3-left" >
        <center><li class="w3-dark-grey w3-xlarge w3-padding-42 ">PROFIL</li></center>
        <li class="w3-padding-16">Nama : Bella Chandra Devi</li>
        <li class="w3-padding-16">Nim : 14.01.55.0052</li>
		  <li class="w3-padding-16">Prodi : Sistem Informasi</li>
        <li class="w3-padding-16">Fakultas : Teknologi Informasi</li>
        
        </li>
      </ul>
    </div>
</html>