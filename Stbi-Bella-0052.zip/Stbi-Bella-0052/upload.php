<html>
<center><br><title>Form Upload</title>
<div><h2>Upload File</h2></div>
<center><form enctype="multipart/form-data" method="POST" action="?menu=hasil_upload">
File yang di upload : <input type="file" name="fupload"><br>
<br>Deskripsi File : <br>
<textarea name="deskripsi" rows="8" cols="40"></textarea><br>
<input type="submit" value="Upload">

</body>
</html>