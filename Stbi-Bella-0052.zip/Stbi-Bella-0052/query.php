<html>
<div align="center"><b><h3>Pencarian Query Boolean </h3></b>
<form enctype="multipart/form-data" method="POST" action="?menu=hasilquery">
Masukan Keyword : <br><p>
<input type="text" name="katakunci">
<input type="submit" value= "submit">
<body>
</form>
</div>
</body>
</html>